package apps;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.filechooser.FileSystemView;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Path2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.management.ManagementFactory;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

/** Info — Datacenter's app launcher, repair console, text inspector, and log viewer. */
public final class Info {
    private static final Path DATA_ROOT = Path.of(System.getProperty("user.home"), "Data");
    private static final Path APPS = DATA_ROOT.resolve("apps");
    private static final Path LOGS = DATA_ROOT.resolve("logs");
    private static final Path BUILD = DATA_ROOT.resolve("runtime").resolve("classes");
    private static final Path CSHARP_BUILD = DATA_ROOT.resolve("runtime").resolve("csharp");
    private static final Path SYSTEM_LOG = LOGS.resolve("system.log");
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
            .withZone(ZoneId.systemDefault());

    private static final Color BACKGROUND = new Color(8, 12, 22);
    private static final Color PANEL = new Color(17, 24, 38);
    private static final Color PANEL_LIGHT = new Color(26, 35, 52);
    private static final Color TEXT = new Color(229, 235, 243);
    private static final Color MUTED = new Color(137, 151, 172);
    private static final Color ACCENT = new Color(78, 210, 226);
    private static final Color GREEN = new Color(89, 214, 142);
    private static final Color RED = new Color(235, 91, 105);

    private final JFrame frame = new JFrame("Info.java — Datacenter App Console");
    private final DefaultListModel<AppEntry> appModel = new DefaultListModel<>();
    private final JList<AppEntry> appList = new JList<>(appModel);
    private final JTextArea preview = textArea();
    private final JTextArea appLog = textArea();
    private final JTextArea systemLog = textArea();
    private final JTextArea details = textArea();
    private final JLabel status = new JLabel("Starting Datacenter inspection…");
    private final JLabel count = new JLabel("0 apps");
    private final ImageIcon sharedIcon = new ImageIcon(createSpaceIcon(72));
    private final ExecutorService worker = Executors.newCachedThreadPool(r -> {
        Thread thread = new Thread(r, "datacenter-info-worker");
        thread.setDaemon(true);
        return thread;
    });

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                Files.createDirectories(APPS);
                Files.createDirectories(LOGS);
                Files.createDirectories(BUILD);
                Files.createDirectories(CSHARP_BUILD);
            } catch (IOException exception) {
                JOptionPane.showMessageDialog(null, exception.getMessage(), "Datacenter startup failure", JOptionPane.ERROR_MESSAGE);
                return;
            }
            new Info().start();
        });
    }

    private Info() {
        configureTheme();
        buildWindow();
    }

    private void start() {
        logSystem("Info.java started; checking all Datacenter applications.");
        logSystem(systemReport().replace('\n', ' '));
        frame.setVisible(true);
        refreshApps();
        repairAllApps();
        new javax.swing.Timer(2_000, event -> refreshVisibleLogs()).start();
    }

    private void configureTheme() {
        UIManager.put("Panel.background", BACKGROUND);
        UIManager.put("Label.foreground", TEXT);
        UIManager.put("List.background", PANEL);
        UIManager.put("List.foreground", TEXT);
        UIManager.put("TextArea.background", PANEL);
        UIManager.put("TextArea.foreground", TEXT);
        UIManager.put("TextArea.caretForeground", ACCENT);
        UIManager.put("TabbedPane.background", BACKGROUND);
        UIManager.put("TabbedPane.foreground", TEXT);
        UIManager.put("Button.background", PANEL_LIGHT);
        UIManager.put("Button.foreground", TEXT);
    }

    private void buildWindow() {
        frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        frame.setSize(1280, 820);
        frame.setMinimumSize(new Dimension(900, 600));
        frame.setLocationRelativeTo(null);
        frame.setIconImage(createSpaceIcon(96));
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override public void windowClosed(java.awt.event.WindowEvent event) { worker.shutdownNow(); }
        });

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BACKGROUND);
        root.add(header(), BorderLayout.NORTH);
        root.add(content(), BorderLayout.CENTER);
        status.setBorder(new EmptyBorder(8, 16, 8, 16));
        status.setForeground(MUTED);
        root.add(status, BorderLayout.SOUTH);
        frame.setContentPane(root);
    }

    private JComponent header() {
        JPanel panel = new JPanel(new BorderLayout(12, 0));
        panel.setBackground(new Color(11, 17, 29));
        panel.setBorder(new EmptyBorder(14, 18, 14, 18));
        JLabel logo = new JLabel(sharedIcon);
        JLabel title = new JLabel("DATACENTER INFO");
        title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 25));
        title.setForeground(ACCENT);
        JLabel subtitle = new JLabel("App repair • launcher • logs • source text • system information");
        subtitle.setForeground(MUTED);
        JPanel names = new JPanel();
        names.setOpaque(false);
        names.setLayout(new BoxLayout(names, BoxLayout.Y_AXIS));
        names.add(title); names.add(subtitle);
        panel.add(logo, BorderLayout.WEST); panel.add(names, BorderLayout.CENTER);
        count.setForeground(MUTED); panel.add(count, BorderLayout.EAST);
        return panel;
    }

    private JComponent content() {
        appList.setCellRenderer(new AppCellRenderer(sharedIcon));
        appList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        appList.addListSelectionListener(this::selectionChanged);
        appList.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent event) { if (event.getClickCount() == 2) openSelectedApp(); }
        });

        JPanel left = new JPanel(new BorderLayout(0, 8));
        left.setBorder(new EmptyBorder(12, 12, 12, 6));
        left.setPreferredSize(new Dimension(320, 600));
        left.add(new JScrollPane(appList), BorderLayout.CENTER);
        JPanel buttons = new JPanel(new GridLayout(2, 2, 7, 7));
        buttons.add(button("Open app", this::openSelectedApp));
        buttons.add(button("Create app", this::createApp));
        buttons.add(button("Repair all", this::repairAllApps));
        buttons.add(button("Refresh", this::refreshApps));
        left.add(buttons, BorderLayout.SOUTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("File text", scroll(preview));
        tabs.addTab("App log", scroll(appLog));
        tabs.addTab("System app logs", scroll(systemLog));
        tabs.addTab("Details", scroll(details));
        JPanel right = new JPanel(new BorderLayout());
        right.setBorder(new EmptyBorder(12, 6, 12, 12));
        right.add(tabs);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, left, right);
        split.setResizeWeight(0.24); split.setDividerSize(5); split.setBorder(null);
        return split;
    }

    private JButton button(String text, Runnable action) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(48, 64, 83)), new EmptyBorder(9, 10, 9, 10)));
        button.addActionListener(event -> action.run());
        return button;
    }

    private static JTextArea textArea() {
        JTextArea area = new JTextArea();
        area.setEditable(false); area.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        area.setLineWrap(false); area.setTabSize(4); area.setBorder(new EmptyBorder(12, 14, 12, 14));
        return area;
    }

    private static JScrollPane scroll(JTextArea area) { return new JScrollPane(area); }

    private void refreshApps() {
        AppEntry selected = appList.getSelectedValue();
        List<AppEntry> entries = new ArrayList<>();
        try (Stream<Path> stream = Files.list(APPS)) {
            stream.filter(Files::isRegularFile)
                    .filter(path -> !path.getFileName().toString().startsWith("."))
                    .sorted(Comparator.comparing(path -> path.getFileName().toString().toLowerCase(Locale.ROOT)))
                    .map(AppEntry::new).forEach(entries::add);
        } catch (IOException exception) {
            setStatus("Could not list apps: " + exception.getMessage(), false); return;
        }
        appModel.clear(); entries.forEach(appModel::addElement);
        count.setText(entries.size() + (entries.size() == 1 ? " app" : " apps"));
        if (selected != null) {
            for (int i = 0; i < appModel.size(); i++)
                if (appModel.get(i).path.equals(selected.path)) { appList.setSelectedIndex(i); return; }
        }
        if (!appModel.isEmpty()) appList.setSelectedIndex(0);
    }

    private void selectionChanged(ListSelectionEvent event) {
        if (!event.getValueIsAdjusting()) loadSelected();
    }

    private void loadSelected() {
        AppEntry app = appList.getSelectedValue();
        if (app == null) return;
        preview.setText(readText(app.path, 2_000_000)); preview.setCaretPosition(0);
        appLog.setText(readText(logPath(app), 2_000_000)); appLog.setCaretPosition(0);
        details.setText(detailsFor(app)); details.setCaretPosition(0);
        systemLog.setText(readAllLogs()); systemLog.setCaretPosition(Math.max(0, systemLog.getDocument().getLength()));
    }

    private void refreshVisibleLogs() {
        AppEntry app = appList.getSelectedValue();
        if (app != null) appLog.setText(readText(logPath(app), 2_000_000));
        systemLog.setText(readAllLogs());
    }

    private String detailsFor(AppEntry app) {
        try {
            BasicFileAttributes attrs = Files.readAttributes(app.path, BasicFileAttributes.class);
            long lines;
            try (Stream<String> stream = Files.lines(app.path, StandardCharsets.UTF_8)) { lines = stream.count(); }
            Path version = DATA_ROOT.resolve("versions").resolve(app.path.getFileName() + ".version");
            return "File name: " + app.path.getFileName() + "\n"
                    + "Full path: " + app.path + "\n"
                    + "Type: " + app.type + "\n"
                    + "Size: " + humanBytes(attrs.size()) + "\n"
                    + "Lines: " + String.format("%,d", lines) + "\n"
                    + "Modified: " + TIME.format(attrs.lastModifiedTime().toInstant()) + "\n"
                    + "Readable: " + Files.isReadable(app.path) + "\n"
                    + "Writable: " + Files.isWritable(app.path) + "\n"
                    + "Executable: " + Files.isExecutable(app.path) + "\n\n"
                    + "Version metadata:\n" + readText(version, 32_000);
        } catch (IOException exception) { return "Could not inspect app: " + exception.getMessage(); }
    }

    private void repairAllApps() {
        setStatus("Repairing and validating applications…", true);
        worker.submit(() -> {
            int passed = 0, failed = 0;
            List<AppEntry> apps = Collections.list(appModel.elements());
            for (AppEntry app : apps) {
                if (!app.type.equals("Java source") && !app.type.equals("C# source")) {
                    logApp(app, "CHECK: app is present and readable=" + Files.isReadable(app.path)); passed++; continue;
                }
                if (compileApp(app)) passed++; else failed++;
            }
            int finalPassed = passed, finalFailed = failed;
            logSystem("Repair scan complete: " + passed + " passed, " + failed + " failed.");
            SwingUtilities.invokeLater(() -> {
                setStatus("Repair complete: " + finalPassed + " passed, " + finalFailed + " need attention.", finalFailed == 0);
                loadSelected();
            });
        });
    }

    private boolean compileApp(AppEntry app) {
        return app.type.equals("C# source") ? compileCSharp(app) : compileJava(app);
    }

    private boolean compileJava(AppEntry app) {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) { logApp(app, "REPAIR FAILED: JDK compiler is not installed."); return false; }
        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        try (StandardJavaFileManager manager = compiler.getStandardFileManager(diagnostics, Locale.ROOT, StandardCharsets.UTF_8)) {
            Iterable<? extends JavaFileObject> units = manager.getJavaFileObjects(app.path.toFile());
            List<String> options = List.of("-d", BUILD.toString(), "-Xlint:all");
            boolean ok = Boolean.TRUE.equals(compiler.getTask(null, manager, diagnostics, options, null, units).call());
            StringBuilder report = new StringBuilder(ok ? "REPAIR OK: compiled successfully." : "REPAIR FAILED: compiler errors detected.");
            for (Diagnostic<? extends JavaFileObject> diagnostic : diagnostics.getDiagnostics())
                report.append("\n  line ").append(diagnostic.getLineNumber()).append(": ").append(diagnostic.getMessage(Locale.ROOT));
            logApp(app, report.toString()); return ok;
        } catch (IOException exception) { logApp(app, "REPAIR FAILED: " + exception.getMessage()); return false; }
    }

    private boolean compileCSharp(AppEntry app) {
        if (!commandExists("dotnet")) { logApp(app, "REPAIR FAILED: dotnet SDK is not installed."); return false; }
        String assembly = toClassName(baseName(app.path));
        Path projectDirectory = CSHARP_BUILD.resolve(assembly);
        Path project = projectDirectory.resolve(assembly + ".csproj");
        Path output = projectDirectory.resolve("out");
        String sourcePath = xmlEscape(app.path.toAbsolutePath().toString());
        String projectText = """
                <Project Sdk="Microsoft.NET.Sdk">
                  <PropertyGroup>
                    <OutputType>Exe</OutputType>
                    <TargetFramework>net10.0</TargetFramework>
                    <AssemblyName>%s</AssemblyName>
                    <EnableDefaultCompileItems>false</EnableDefaultCompileItems>
                    <ImplicitUsings>enable</ImplicitUsings>
                    <Nullable>enable</Nullable>
                  </PropertyGroup>
                  <ItemGroup><Compile Include="%s" Link="%s.cs" /></ItemGroup>
                </Project>
                """.formatted(assembly, sourcePath, assembly);
        try {
            Files.createDirectories(projectDirectory);
            Files.writeString(project, projectText, StandardCharsets.UTF_8);
            ProcessBuilder builder = new ProcessBuilder("dotnet", "build", project.toString(), "--nologo", "--verbosity", "minimal", "--output", output.toString());
            builder.directory(APPS.toFile()); builder.redirectErrorStream(true);
            Process process = builder.start();
            String report = new String(process.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
            int exit = process.waitFor();
            logApp(app, (exit == 0 ? "REPAIR OK: C# compiled successfully." : "REPAIR FAILED: C# compiler errors detected.") + "\n" + report.strip());
            return exit == 0;
        } catch (IOException exception) {
            logApp(app, "REPAIR FAILED: " + exception.getMessage()); return false;
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt(); logApp(app, "REPAIR CANCELLED: interrupted."); return false;
        }
    }

    private void openSelectedApp() {
        AppEntry app = appList.getSelectedValue();
        if (app == null) { setStatus("Select an app first.", false); return; }
        showStartingWindow(app, () -> worker.submit(() -> launch(app)));
    }

    private void showStartingWindow(AppEntry app, Runnable after) {
        JDialog splash = new JDialog(frame, app.path.getFileName().toString(), false);
        splash.setIconImage(createSpaceIcon(72));
        JPanel panel = new JPanel(); panel.setBorder(new EmptyBorder(25, 38, 25, 38));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        JLabel icon = new JLabel(new ImageIcon(createSpaceIcon(110))); icon.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel name = new JLabel(app.path.getFileName().toString()); name.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20)); name.setForeground(TEXT); name.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel opening = new JLabel("Opening from Datacenter…"); opening.setForeground(MUTED); opening.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(icon); panel.add(Box.createVerticalStrut(10)); panel.add(name); panel.add(Box.createVerticalStrut(5)); panel.add(opening);
        splash.setContentPane(panel); splash.pack(); splash.setLocationRelativeTo(frame); splash.setVisible(true);
        new javax.swing.Timer(850, event -> { ((javax.swing.Timer) event.getSource()).stop(); splash.dispose(); after.run(); }).start();
    }

    private void launch(AppEntry app) {
        try {
            ProcessBuilder builder;
            if (app.type.equals("Java source")) {
                if (!compileApp(app)) { SwingUtilities.invokeLater(() -> setStatus(app + " has compiler errors. See App log.", false)); return; }
                String className = "apps." + baseName(app.path);
                builder = new ProcessBuilder("java", "-cp", BUILD.toString(), className);
            } else if (app.type.equals("C# source")) {
                if (!compileApp(app)) { SwingUtilities.invokeLater(() -> setStatus(app + " has compiler errors. See App log.", false)); return; }
                String assembly = toClassName(baseName(app.path));
                Path dll = CSHARP_BUILD.resolve(assembly).resolve("out").resolve(assembly + ".dll");
                builder = new ProcessBuilder("dotnet", dll.toString());
            } else if (app.type.equals("Shell script")) {
                builder = new ProcessBuilder("bash", app.path.toString());
            } else if (Files.isExecutable(app.path)) {
                builder = new ProcessBuilder(app.path.toString());
            } else if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(app.path.toFile()); logApp(app, "OPEN: handed to the desktop application."); return;
            } else { logApp(app, "OPEN FAILED: no application is available for this file type."); return; }

            Files.createDirectories(LOGS);
            builder.directory(APPS.toFile()); builder.redirectErrorStream(true); builder.redirectOutput(ProcessBuilder.Redirect.appendTo(logPath(app).toFile()));
            logApp(app, "LAUNCH: " + String.join(" ", builder.command()));
            Process process = builder.start();
            setStatusOnEdt("Running " + app + " (PID " + process.pid() + ")", true);
            int exit = process.waitFor();
            logApp(app, "EXIT: process returned " + exit);
            setStatusOnEdt(app + " exited with code " + exit, exit == 0);
        } catch (Exception exception) {
            logApp(app, "LAUNCH FAILED: " + stackTrace(exception));
            setStatusOnEdt("Could not open " + app + ": " + exception.getMessage(), false);
        }
    }

    private void createApp() {
        JTextField nameField = new JTextField(20);
        JComboBox<String> language = new JComboBox<>(new String[]{"Java", "C#"});
        JPanel form = new JPanel(new GridLayout(2, 2, 8, 8));
        form.add(new JLabel("Application name:")); form.add(nameField);
        form.add(new JLabel("Language:")); form.add(language);
        int choice = JOptionPane.showConfirmDialog(frame, form, "Create Datacenter App", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (choice != JOptionPane.OK_OPTION) return;
        String entered = nameField.getText();
        if (entered == null || entered.isBlank()) return;
        String className = toClassName(entered);
        if (className.isBlank()) { JOptionPane.showMessageDialog(frame, "Use letters and numbers in the name.", "Invalid name", JOptionPane.ERROR_MESSAGE); return; }
        boolean csharp = "C#".equals(language.getSelectedItem());
        Path target = APPS.resolve(className + (csharp ? ".cs" : ".java")).normalize();
        if (!target.getParent().equals(APPS) || Files.exists(target)) { JOptionPane.showMessageDialog(frame, "That app already exists.", "Cannot create", JOptionPane.ERROR_MESSAGE); return; }
        try {
            Files.writeString(target, csharp ? csharpAppTemplate(className) : appTemplate(className), StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW);
            AppEntry entry = new AppEntry(target); logApp(entry, "CREATE: generated a Datacenter window app with the shared procedural icon.");
            logSystem("Created application " + target.getFileName()); refreshApps();
            for (int i = 0; i < appModel.size(); i++) if (appModel.get(i).path.equals(target)) appList.setSelectedIndex(i);
            repairAllApps();
        } catch (IOException exception) { JOptionPane.showMessageDialog(frame, exception.getMessage(), "Create failed", JOptionPane.ERROR_MESSAGE); }
    }

    private static String appTemplate(String className) {
        return """
                package apps;

                import javax.swing.*;
                import java.awt.*;
                import java.awt.geom.Path2D;
                import java.awt.image.BufferedImage;

                public final class %s {
                    public static void main(String[] args) {
                        SwingUtilities.invokeLater(() -> {
                            JFrame frame = new JFrame("%s.java");
                            frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
                            frame.setSize(800, 520);
                            frame.setLocationRelativeTo(null);
                            frame.setIconImage(icon(96));
                            JTextArea text = new JTextArea("%s is ready.\\n\\nWrite your app here.");
                            text.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 16));
                            text.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
                            frame.add(new JScrollPane(text));
                            frame.setVisible(true);
                        });
                    }

                    private static Image icon(int size) {
                        BufferedImage image = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
                        Graphics2D g = image.createGraphics();
                        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        g.setPaint(new GradientPaint(0, 0, new Color(5, 9, 25), size, size, new Color(20, 7, 45)));
                        g.fillRect(0, 0, size, size);
                        Path2D star = new Path2D.Double(); int edges = 18;
                        for (int i = 0; i < edges * 2; i++) { double a = -Math.PI / 2 + i * Math.PI / edges; double r = i %% 2 == 0 ? size * .39 : size * .24; double x = size / 2.0 + Math.cos(a) * r, y = size / 2.0 + Math.sin(a) * r; if (i == 0) star.moveTo(x, y); else star.lineTo(x, y); }
                        star.closePath(); g.setColor(new Color(70, 220, 238)); g.fill(star); g.setStroke(new BasicStroke(Math.max(1, size / 28f))); g.setColor(new Color(192, 119, 255)); g.draw(star); g.dispose(); return image;
                    }
                }
                """.formatted(className, className, className);
    }

    private static String csharpAppTemplate(String className) {
        return """
                using System;

                internal static class %s
                {
                    private static void Main()
                    {
                        Console.Title = "%s.cs";
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("        .       *        .");
                        Console.WriteLine("     *     /\\\\|/\\\\     *");
                        Console.WriteLine("   .      <  DATA  >      .");
                        Console.WriteLine("     *     \\//|\\//     *");
                        Console.WriteLine("        .       *        .");
                        Console.ResetColor();
                        Console.WriteLine("%s.cs is ready.");
                        Console.WriteLine("Press Enter to close.");
                        Console.ReadLine();
                    }
                }
                """.formatted(className, className, className);
    }

    private static BufferedImage createSpaceIcon(int size) {
        BufferedImage image = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = image.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setPaint(new GradientPaint(0, 0, new Color(5, 9, 25), size, size, new Color(24, 7, 49))); g.fillRoundRect(0, 0, size, size, size / 5, size / 5);
        for (int i = 0; i < 22; i++) { int x = (i * 37 + 11) % size, y = (i * 23 + 7) % size; g.setColor(new Color(220, 235, 255, 80 + i % 3 * 50)); g.fillOval(x, y, Math.max(1, size / 48), Math.max(1, size / 48)); }
        Path2D polygon = new Path2D.Double(); int edges = 18;
        for (int i = 0; i < edges * 2; i++) { double angle = -Math.PI / 2 + i * Math.PI / edges; double radius = i % 2 == 0 ? size * .37 : size * .23; double x = size / 2.0 + Math.cos(angle) * radius, y = size / 2.0 + Math.sin(angle) * radius; if (i == 0) polygon.moveTo(x, y); else polygon.lineTo(x, y); }
        polygon.closePath(); g.setColor(new Color(69, 218, 235, 225)); g.fill(polygon); g.setStroke(new BasicStroke(Math.max(1, size / 25f))); g.setColor(new Color(190, 118, 255)); g.draw(polygon);
        g.setColor(new Color(8, 14, 28)); g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, Math.max(11, size / 3))); FontMetrics fm = g.getFontMetrics(); String d = "D"; g.drawString(d, (size - fm.stringWidth(d)) / 2, (size - fm.getHeight()) / 2 + fm.getAscent()); g.dispose(); return image;
    }

    private static String readText(Path path, int maximum) {
        if (!Files.isRegularFile(path)) return "No data yet: " + path.getFileName();
        try {
            long size = Files.size(path); byte[] bytes;
            if (size <= maximum) bytes = Files.readAllBytes(path);
            else { try (var input = Files.newInputStream(path)) { input.skip(size - maximum); bytes = input.readNBytes(maximum); } }
            return (size > maximum ? "… showing final " + maximum + " bytes …\n" : "") + new String(bytes, StandardCharsets.UTF_8);
        } catch (IOException exception) { return "Could not read: " + exception.getMessage(); }
    }

    private static String readAllLogs() {
        StringBuilder combined = new StringBuilder("DATACENTER LOG COLLECTION\n");
        List<Path> paths = new ArrayList<>();
        try (Stream<Path> stream = Files.list(LOGS)) {
            stream.filter(Files::isRegularFile).sorted().forEach(paths::add);
        } catch (IOException exception) {
            combined.append("Could not list logs: ").append(exception.getMessage()).append('\n');
        }
        Path managerLog = DATA_ROOT.resolve("manager").resolve("manager.log");
        if (Files.isRegularFile(managerLog)) paths.add(managerLog);
        for (Path path : paths) {
            combined.append("\n══════════ ").append(path.getFileName()).append(" ══════════\n");
            combined.append(readText(path, 400_000)).append('\n');
        }
        return combined.toString();
    }

    private static String systemReport() {
        Runtime runtime = Runtime.getRuntime();
        return "Time: " + TIME.format(Instant.now()) + "\nJava: " + System.getProperty("java.version") + "\nOS: " + System.getProperty("os.name") + " " + System.getProperty("os.version") + "\nArchitecture: " + System.getProperty("os.arch") + "\nProcessors: " + runtime.availableProcessors() + "\nJVM memory: " + humanBytes(runtime.totalMemory() - runtime.freeMemory()) + " used / " + humanBytes(runtime.maxMemory()) + " maximum\nPID: " + ProcessHandle.current().pid() + "\nUptime: " + ManagementFactory.getRuntimeMXBean().getUptime() + " ms\nApps path: " + APPS;
    }

    private static synchronized void appendLog(Path path, String message) {
        try { Files.createDirectories(path.getParent()); Files.writeString(path, "[" + TIME.format(Instant.now()) + "] " + message + "\n", StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND); }
        catch (IOException exception) { System.err.println("Logging failed: " + exception.getMessage()); }
    }

    private static void logSystem(String message) { appendLog(SYSTEM_LOG, message); }
    private static void logApp(AppEntry app, String message) { appendLog(logPath(app), message); appendLog(SYSTEM_LOG, app + ": " + message.replace('\n', ' ')); }
    private static Path logPath(AppEntry app) { return LOGS.resolve(app.path.getFileName().toString().replaceAll("[^A-Za-z0-9._-]", "_") + ".log"); }
    private static String baseName(Path path) { String name = path.getFileName().toString(); int dot = name.lastIndexOf('.'); return dot > 0 ? name.substring(0, dot) : name; }
    private static boolean commandExists(String command) { String path = System.getenv("PATH"); if (path == null) return false; for (String directory : path.split(java.io.File.pathSeparator)) if (Files.isExecutable(Path.of(directory, command))) return true; return false; }
    private static String xmlEscape(String value) { return value.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;").replace(">", "&gt;"); }
    private static String toClassName(String name) { StringBuilder result = new StringBuilder(); for (String part : name.split("[^A-Za-z0-9]+")) if (!part.isEmpty()) result.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1)); if (!result.isEmpty() && Character.isDigit(result.charAt(0))) result.insert(0, "App"); return result.toString(); }
    private static String humanBytes(long bytes) { String[] units = {"B", "KB", "MB", "GB", "TB"}; double value = bytes; int unit = 0; while (value >= 1024 && unit < units.length - 1) { value /= 1024; unit++; } return String.format(Locale.ROOT, unit == 0 ? "%.0f %s" : "%.2f %s", value, units[unit]); }
    private static String stackTrace(Throwable error) { StringWriter text = new StringWriter(); error.printStackTrace(new PrintWriter(text)); return text.toString(); }
    private void setStatus(String text, boolean good) { status.setText(text); status.setForeground(good ? GREEN : RED); }
    private void setStatusOnEdt(String text, boolean good) { SwingUtilities.invokeLater(() -> setStatus(text, good)); }

    private record AppEntry(Path path, String type) {
        AppEntry(Path path) { this(path, detectType(path)); }
        private static String detectType(Path path) { String name = path.getFileName().toString().toLowerCase(Locale.ROOT); if (name.endsWith(".java")) return "Java source"; if (name.endsWith(".cs")) return "C# source"; if (name.endsWith(".sh")) return "Shell script"; if (Files.isExecutable(path)) return "Executable"; return "Data / text"; }
        @Override public String toString() { return path.getFileName().toString(); }
    }

    @SuppressWarnings("serial")
    private static final class AppCellRenderer extends DefaultListCellRenderer {
        private final Icon icon;
        AppCellRenderer(Icon icon) { this.icon = icon; }
        @Override public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean selected, boolean focus) {
            JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, selected, focus);
            label.setIcon(icon); label.setIconTextGap(12); label.setBorder(new EmptyBorder(7, 8, 7, 8));
            if (!selected) { label.setBackground(PANEL); label.setForeground(TEXT); }
            return label;
        }
    }
}
