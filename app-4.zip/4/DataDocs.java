

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.GridBagLayout;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class DataDocs {
    // Theme Colors
    private static final Color BG_DARK = new Color(24, 26, 27);
    private static final Color BG_LIGHT = new Color(34, 38, 41);
    private static final Color TEXT_COLOR = new Color(228, 224, 218);
    private static final Color ACCENT_COLOR = new Color(14, 134, 212);
    private static final Color ACCENT_HOVER = new Color(24, 154, 232);
    private static final Color SECONDARY_COLOR = new Color(60, 64, 67);
    private static final Color SECONDARY_HOVER = new Color(80, 84, 87);

    // Typography
    private static final Font MAIN_FONT = new Font("Segoe UI", Font.PLAIN, 14);

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Datadocs");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(950, 700); // Widened slightly to fit the new font size dropdown
            frame.setLocationRelativeTo(null);
            frame.getContentPane().setBackground(BG_DARK);

            showWelcomeScreen(frame);

            frame.setVisible(true);
        });
    }

    private static void showWelcomeScreen(JFrame frame) {
        frame.getContentPane().removeAll();
        frame.setLayout(new GridBagLayout());

        JButton newDocButton = createStyledButton("New Document", ACCENT_COLOR, ACCENT_HOVER);
        newDocButton.setPreferredSize(new Dimension(200, 60));
        newDocButton.addActionListener(e -> createNewDocScreen(frame));

        frame.add(newDocButton);
        frame.revalidate();
        frame.repaint();
    }

    private static void createNewDocScreen(JFrame frame) {
        frame.getContentPane().removeAll();
        frame.setLayout(new BorderLayout());

        // Text Area Editor Setup
        JTextArea docArea = new JTextArea();
        docArea.setFont(new Font("Consolas", Font.PLAIN, 16));
        docArea.setBackground(BG_DARK);
        docArea.setForeground(TEXT_COLOR);
        docArea.setCaretColor(TEXT_COLOR);
        docArea.setLineWrap(true);
        docArea.setWrapStyleWord(true);
        docArea.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Top Control Bar
        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 10));
        topBar.setBackground(BG_LIGHT);
        topBar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BG_DARK));

        // --- Feature 1: 100+ System Font Dropdown ---
        String[] fontNames = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
        JComboBox<String> fontMenu = new JComboBox<>(fontNames);
        fontMenu.setSelectedItem("Consolas"); 
        fontMenu.setFont(MAIN_FONT);
        fontMenu.setPreferredSize(new Dimension(180, 35));

        // --- Feature 2: Font Sizes Dropdown ---
        Integer[] fontSizes = {12, 14, 16, 18, 20, 22, 24, 28, 32, 36, 40, 48};
        JComboBox<Integer> sizeMenu = new JComboBox<>(fontSizes);
        sizeMenu.setSelectedItem(16); // Match default font area setting
        sizeMenu.setFont(MAIN_FONT);
        sizeMenu.setPreferredSize(new Dimension(70, 35));

        // Unified Action Listener function to change font name and size together
        java.awt.event.ActionListener fontChangeListener = e -> {
            String selectedFont = (String) fontMenu.getSelectedItem();
            Integer selectedSize = (Integer) sizeMenu.getSelectedItem();
            if (selectedFont != null && selectedSize != null) {
                docArea.setFont(new Font(selectedFont, Font.PLAIN, selectedSize));
            }
        };
        fontMenu.addActionListener(fontChangeListener);
        sizeMenu.addActionListener(fontChangeListener);

        // --- Feature 3: Print System Integration ---
        JButton printButton = createStyledButton("Print", SECONDARY_COLOR, SECONDARY_HOVER);
        printButton.setPreferredSize(new Dimension(90, 35));
        printButton.addActionListener(e -> {
            new Thread(() -> {
                try {
                    boolean complete = docArea.print();
                    if (complete) {
                        SwingUtilities.invokeLater(() -> 
                            JOptionPane.showMessageDialog(frame, "Printing Complete", "Success", JOptionPane.INFORMATION_MESSAGE)
                        );
                    }
                } catch (Exception ex) {
                    SwingUtilities.invokeLater(() -> 
                        JOptionPane.showMessageDialog(frame, "Printing Failed: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE)
                    );
                }
            }).start();
        });

        // --- Feature 4: Native File System Saving ---
        JButton saveButton = createStyledButton("Save Document", ACCENT_COLOR, ACCENT_HOVER);
        saveButton.setPreferredSize(new Dimension(140, 35));
        saveButton.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Save Your Document");
            int userSelection = fileChooser.showSaveDialog(frame);
            
            if (userSelection == JFileChooser.APPROVE_OPTION) {
                File fileToSave = fileChooser.getSelectedFile();
                if (!fileToSave.getName().toLowerCase().endsWith(".txt")) {
                    fileToSave = new File(fileToSave.getAbsolutePath() + ".txt");
                }
                try (FileWriter writer = new FileWriter(fileToSave)) {
                    writer.write(docArea.getText());
                    JOptionPane.showMessageDialog(frame, "File saved successfully!", "Saved", JOptionPane.INFORMATION_MESSAGE);
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(frame, "Error saving file: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        JButton backButton = createStyledButton("Back to Menu", SECONDARY_COLOR, SECONDARY_HOVER);
        backButton.setPreferredSize(new Dimension(120, 35));
        backButton.addActionListener(e -> showWelcomeScreen(frame));

        // Assemble Bar elements
        topBar.add(backButton);
        topBar.add(fontMenu);
        topBar.add(sizeMenu); // Insert size picker directly between font name and printer buttons
        topBar.add(printButton);
        topBar.add(saveButton);

        JScrollPane scrollPane = new JScrollPane(docArea);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        frame.add(topBar, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);

        frame.revalidate();
        frame.repaint();
    }

    // Custom Rounded Button Creator
    private static JButton createStyledButton(String text, Color baseColor, Color hoverColor) {
        // We override paintComponent below to inject beautiful anti-aliased pill styling 
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Draw rounded background canvas panel
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 16, 16); // 16px corner roundness
                
                // Draw standard text overlays on top of the geometry layout safely
                g2.setColor(getForeground());
                g2.setFont(getFont());
                var metrics = g2.getFontMetrics();
                int x = (getWidth() - metrics.stringWidth(getText())) / 2;
                int y = ((getHeight() - metrics.getHeight()) / 2) + metrics.getAscent();
                g2.drawString(getText(), x, y);
                g2.dispose();
            }
        };

        button.setFont(MAIN_FONT);
        button.setBackground(baseColor);
        button.setForeground(Color.WHITE);
        button.setContentAreaFilled(false); // Essential: Disables original blocky background drawing
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(hoverColor);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(baseColor);
            }
        });

        return button;
    }
}