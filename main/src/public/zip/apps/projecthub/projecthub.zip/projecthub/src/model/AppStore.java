package model;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;

/** Small dependency-free data store shared by every page. */
public final class AppStore {
    public record Project(String name, String description, String status, int progress) implements Serializable {}
    public record Task(String title, String project, String priority, String status, String due) implements Serializable {}
    public record Bug(String title, String project, String severity, String status) implements Serializable {}
    public record Version(String version, String project, String status, String date) implements Serializable {}

    private static final AppStore INSTANCE = new AppStore();
    private final List<Project> projects = new ArrayList<>();
    private final List<Task> tasks = new ArrayList<>();
    private final List<Bug> bugs = new ArrayList<>();
    private final List<Version> versions = new ArrayList<>();
    private final List<Runnable> listeners = new ArrayList<>();
    private final Path file = Path.of(System.getProperty("user.home"), ".projecthub", "data.ser");

    public static AppStore get() { return INSTANCE; }
    private AppStore() { load(); }
    public List<Project> projects() { return Collections.unmodifiableList(projects); }
    public List<Task> tasks() { return Collections.unmodifiableList(tasks); }
    public List<Bug> bugs() { return Collections.unmodifiableList(bugs); }
    public List<Version> versions() { return Collections.unmodifiableList(versions); }
    public void listen(Runnable listener) { listeners.add(listener); }

    public void addProject(Project value) { projects.add(value); changed(); }
    public void addTask(Task value) { tasks.add(value); changed(); }
    public void addBug(Bug value) { bugs.add(value); changed(); }
    public void addVersion(Version value) { versions.add(value); changed(); }
    public void removeProject(int i) { if (valid(i, projects)) { String name=projects.remove(i).name(); tasks.removeIf(x->x.project().equals(name)); bugs.removeIf(x->x.project().equals(name)); versions.removeIf(x->x.project().equals(name)); changed(); } }
    public void removeTask(int i) { if (valid(i, tasks)) { tasks.remove(i); changed(); } }
    public void removeBug(int i) { if (valid(i, bugs)) { bugs.remove(i); changed(); } }
    public void removeVersion(int i) { if (valid(i, versions)) { versions.remove(i); changed(); } }
    public void updateTask(int i, Task value) { if (valid(i, tasks)) { tasks.set(i, value); changed(); } }
    public void updateBug(int i, Bug value) { if (valid(i, bugs)) { bugs.set(i, value); changed(); } }
    private boolean valid(int i, List<?> list) { return i >= 0 && i < list.size(); }

    public void seedDemo() {
        if (!projects.isEmpty()) return;
        projects.add(new Project("ProjectHub", "Desktop project planning workspace", "Active", 65));
        tasks.add(new Task("Finish dashboard", "ProjectHub", "High", "In progress", LocalDate.now().plusDays(3).toString()));
        bugs.add(new Bug("Empty state alignment", "ProjectHub", "Low", "Open"));
        versions.add(new Version("1.0.0", "ProjectHub", "Planned", LocalDate.now().plusWeeks(2).toString()));
        changed();
    }

    public void clear() { projects.clear(); tasks.clear(); bugs.clear(); versions.clear(); changed(); }
    private void changed() { save(); List.copyOf(listeners).forEach(Runnable::run); }
    private void save() {
        try { Files.createDirectories(file.getParent()); try (var out = new ObjectOutputStream(Files.newOutputStream(file))) { out.writeObject(new ArrayList<>(projects)); out.writeObject(new ArrayList<>(tasks)); out.writeObject(new ArrayList<>(bugs)); out.writeObject(new ArrayList<>(versions)); } }
        catch (IOException e) { System.err.println("Could not save ProjectHub data: " + e.getMessage()); }
    }
    @SuppressWarnings("unchecked") private void load() {
        if (!Files.exists(file)) return;
        try (var in = new ObjectInputStream(Files.newInputStream(file))) { projects.addAll((List<Project>)in.readObject()); tasks.addAll((List<Task>)in.readObject()); bugs.addAll((List<Bug>)in.readObject()); versions.addAll((List<Version>)in.readObject()); }
        catch (IOException | ClassNotFoundException e) { System.err.println("Could not load ProjectHub data: " + e.getMessage()); }
    }
}
