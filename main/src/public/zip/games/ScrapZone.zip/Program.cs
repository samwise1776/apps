using Raylib_cs;
using System.Numerics;

public static class Program
{
    const int W = 1000, H = 700;
    const float ArenaTop = 82;
    static readonly Random rng = new();
    static readonly List<Enemy> enemies = [];
    static readonly List<Bullet> bullets = [];
    static readonly List<Pickup> pickups = [];
    static readonly List<Particle> particles = [];
    static readonly List<Floater> floaters = [];

    static GameState state = GameState.Title;
    static Vector2 player, aim;
    static float speed, fireDelay, fireTimer, invincible, dashCooldown, dashTime, shake;
    static int health, maxHealth, damage, scrap, score, wave, kills, shots, hits;
    static float waveTime, spawnTimer, bannerTime;
    static bool bossSpawned;
    static Upgrade[] choices = new Upgrade[3];

    public static void Main()
    {
        Raylib.InitWindow(W, H, "ScrapZone: Last Salvager");
        Raylib.SetTargetFPS(60);
        Reset();
        state = GameState.Title;

        while (!Raylib.WindowShouldClose())
        {
            float dt = Math.Min(Raylib.GetFrameTime(), .05f);
            Update(dt);
            Draw();
        }
        Raylib.CloseWindow();
    }

    static void Reset()
    {
        player = new(W / 2, H / 2); aim = Vector2.UnitX;
        speed = 260; fireDelay = .22f; damage = 20;
        maxHealth = health = 100;
        scrap = score = kills = shots = hits = 0;
        wave = 1; waveTime = 0; spawnTimer = 1; bannerTime = 2.5f;
        fireTimer = invincible = dashCooldown = dashTime = shake = 0;
        bossSpawned = false;
        enemies.Clear(); bullets.Clear(); pickups.Clear(); particles.Clear(); floaters.Clear();
    }

    static void StartGame() { Reset(); state = GameState.Playing; }

    static void Update(float dt)
    {
        if (state == GameState.Title)
        {
            if (Raylib.IsKeyPressed(KeyboardKey.Enter) || Raylib.IsMouseButtonPressed(MouseButton.Left)) StartGame();
            return;
        }
        if (state is GameState.GameOver or GameState.Victory)
        {
            UpdateEffects(dt);
            if (Raylib.IsKeyPressed(KeyboardKey.R) || Raylib.IsKeyPressed(KeyboardKey.Enter)) StartGame();
            return;
        }
        if (state == GameState.Upgrade)
        {
            UpdateEffects(dt);
            if (Raylib.IsKeyPressed(KeyboardKey.One)) PickUpgrade(0);
            if (Raylib.IsKeyPressed(KeyboardKey.Two)) PickUpgrade(1);
            if (Raylib.IsKeyPressed(KeyboardKey.Three)) PickUpgrade(2);
            return;
        }
        if (Raylib.IsKeyPressed(KeyboardKey.P) || Raylib.IsKeyPressed(KeyboardKey.Escape))
        { state = state == GameState.Paused ? GameState.Playing : GameState.Paused; }
        if (state == GameState.Paused) return;

        waveTime += dt; bannerTime -= dt; fireTimer -= dt; invincible -= dt; dashCooldown -= dt;
        UpdatePlayer(dt);
        UpdateBullets(dt);
        UpdateEnemies(dt);
        UpdatePickups(dt);
        UpdateEffects(dt);
        SpawnEnemies(dt);

        if (health <= 0) { health = 0; state = GameState.GameOver; Burst(player, Color.Red, 35); }
        if (waveTime >= WaveDuration() && enemies.Count == 0)
        {
            if (wave >= 6) { state = GameState.Victory; score += health * 10 + scrap * 20; }
            else BeginUpgrade();
        }
    }

    static float WaveDuration() => wave == 6 ? 40 : 27;

    static void UpdatePlayer(float dt)
    {
        Vector2 move = new(
            (Raylib.IsKeyDown(KeyboardKey.D) || Raylib.IsKeyDown(KeyboardKey.Right) ? 1 : 0) - (Raylib.IsKeyDown(KeyboardKey.A) || Raylib.IsKeyDown(KeyboardKey.Left) ? 1 : 0),
            (Raylib.IsKeyDown(KeyboardKey.S) || Raylib.IsKeyDown(KeyboardKey.Down) ? 1 : 0) - (Raylib.IsKeyDown(KeyboardKey.W) || Raylib.IsKeyDown(KeyboardKey.Up) ? 1 : 0));
        if (move != Vector2.Zero) move = Vector2.Normalize(move);

        if (Raylib.IsKeyPressed(KeyboardKey.Space) && dashCooldown <= 0 && move != Vector2.Zero)
        { dashTime = .16f; dashCooldown = 1.35f; invincible = .22f; Burst(player, Color.SkyBlue, 12); }
        float multiplier = dashTime > 0 ? 3.4f : 1;
        dashTime -= dt;
        player += move * speed * multiplier * dt;
        player.X = Math.Clamp(player.X, 18, W - 18);
        player.Y = Math.Clamp(player.Y, ArenaTop + 18, H - 18);

        Vector2 mouse = Raylib.GetMousePosition();
        Vector2 target = mouse - player;
        if (target.LengthSquared() > 1) aim = Vector2.Normalize(target);
        bool firing = Raylib.IsMouseButtonDown(MouseButton.Left) || Raylib.IsKeyDown(KeyboardKey.J);
        if (firing && fireTimer <= 0)
        {
            bullets.Add(new Bullet { Position = player + aim * 22, Velocity = aim * 620, Life = 1.25f, Damage = damage });
            fireTimer = fireDelay; shots++;
            for (int i = 0; i < 3; i++) AddParticle(player + aim * 20, Color.Yellow, aim * Rand(-50, -15) + RandomDir() * 25, .18f, 3);
        }
    }

    static void SpawnEnemies(float dt)
    {
        if (waveTime >= WaveDuration()) return;
        if (wave == 6 && waveTime > 3 && !bossSpawned)
        {
            bossSpawned = true;
            enemies.Add(MakeEnemy(EnemyKind.Boss));
            bannerTime = 3;
            return;
        }
        if (wave == 6) return;
        spawnTimer -= dt;
        if (spawnTimer > 0 || enemies.Count >= 35) return;
        float interval = Math.Max(.28f, 1.15f - wave * .12f);
        spawnTimer = interval * Rand(.72f, 1.2f);
        EnemyKind kind = EnemyKind.Chaser;
        int roll = rng.Next(100);
        if (wave >= 2 && roll < 22) kind = EnemyKind.Runner;
        if (wave >= 3 && roll is >= 22 and < 40) kind = EnemyKind.Tank;
        if (wave >= 4 && roll is >= 40 and < 58) kind = EnemyKind.Shooter;
        enemies.Add(MakeEnemy(kind));
    }

    static Enemy MakeEnemy(EnemyKind kind)
    {
        Vector2 p = EdgePoint();
        float scale = 1 + (wave - 1) * .1f;
        return kind switch
        {
            EnemyKind.Runner => new(kind, p, 22 * scale, 190 + wave * 8, 11, 14, Color.Orange),
            EnemyKind.Tank => new(kind, p, 100 * scale, 62 + wave * 3, 24, 27, new Color(155, 80, 55, 255)),
            EnemyKind.Shooter => new(kind, p, 44 * scale, 92, 14, 19, new Color(190, 80, 180, 255)),
            EnemyKind.Boss => new(kind, new(W / 2, ArenaTop + 55), 1400, 58, 25, 55, new Color(205, 55, 45, 255)),
            _ => new(kind, p, 38 * scale, 105 + wave * 7, 15, 18, new Color(185, 65, 50, 255))
        };
    }

    static Vector2 EdgePoint()
    {
        int s = rng.Next(4);
        return s switch { 0 => new(Rand(0, W), ArenaTop - 35), 1 => new(Rand(0, W), H + 35), 2 => new(-35, Rand(ArenaTop, H)), _ => new(W + 35, Rand(ArenaTop, H)) };
    }

    static void UpdateBullets(float dt)
    {
        for (int i = bullets.Count - 1; i >= 0; i--)
        {
            Bullet b = bullets[i]; b.Position += b.Velocity * dt; b.Life -= dt;
            if (b.EnemyShot)
            {
                if (Vector2.Distance(b.Position, player) < 15 + b.Radius)
                { Hurt(b.Damage, b.Position); bullets.RemoveAt(i); continue; }
            }
            else
            {
                bool used = false;
                for (int e = enemies.Count - 1; e >= 0; e--)
                {
                    Enemy enemy = enemies[e];
                    if (Vector2.Distance(b.Position, enemy.Position) < b.Radius + enemy.Radius)
                    {
                        enemy.Health -= b.Damage; hits++; used = true;
                        AddParticle(b.Position, Color.Yellow, RandomDir() * 80, .25f, 4);
                        if (enemy.Health <= 0) KillEnemy(e);
                        break;
                    }
                }
                if (used) { bullets.RemoveAt(i); continue; }
            }
            if (b.Life <= 0 || b.Position.X < -50 || b.Position.X > W + 50 || b.Position.Y < ArenaTop - 50 || b.Position.Y > H + 50) bullets.RemoveAt(i);
        }
    }

    static void UpdateEnemies(float dt)
    {
        for (int i = enemies.Count - 1; i >= 0; i--)
        {
            Enemy e = enemies[i];
            Vector2 delta = player - e.Position;
            float dist = Math.Max(1, delta.Length());
            Vector2 dir = delta / dist;
            e.ShootTimer -= dt;
            if (e.Kind == EnemyKind.Shooter && dist < 360)
            {
                e.Position -= dir * e.Speed * .35f * dt;
                if (e.ShootTimer <= 0) { EnemyShoot(e, dir, 260, 10); e.ShootTimer = 1.5f; }
            }
            else if (e.Kind == EnemyKind.Boss)
            {
                e.Position += dir * e.Speed * dt;
                if (e.ShootTimer <= 0)
                {
                    for (int n = 0; n < 12; n++) EnemyShoot(e, Dir(n * MathF.PI / 6), 210, 9);
                    e.ShootTimer = 1.5f;
                }
            }
            else e.Position += dir * e.Speed * dt;

            if (dist < e.Radius + 16)
            {
                Hurt(e.ContactDamage, e.Position);
                if (e.Kind != EnemyKind.Boss) { Burst(e.Position, e.Color, 9); enemies.RemoveAt(i); }
                else e.Position -= dir * 30;
            }
        }
    }

    static void EnemyShoot(Enemy e, Vector2 dir, float velocity, int amount)
    { bullets.Add(new Bullet { Position = e.Position + dir * e.Radius, Velocity = dir * velocity, Life = 4, Damage = amount, Radius = 6, EnemyShot = true }); }

    static void Hurt(int amount, Vector2 source)
    {
        if (invincible > 0) return;
        health -= amount; invincible = .65f; shake = 9;
        Vector2 push = player - source; if (push != Vector2.Zero) player += Vector2.Normalize(push) * 18;
        Burst(player, Color.Red, 10); floaters.Add(new Floater(player, $"-{amount}", Color.Red));
    }

    static void KillEnemy(int index)
    {
        Enemy e = enemies[index]; enemies.RemoveAt(index); kills++;
        int value = e.Kind == EnemyKind.Boss ? 1000 : (int)e.Radius * 4;
        score += value; Burst(e.Position, e.Color, e.Kind == EnemyKind.Boss ? 55 : 14);
        floaters.Add(new Floater(e.Position, $"+{value}", Color.Yellow));
        int drops = e.Kind == EnemyKind.Boss ? 18 : (rng.NextDouble() < .72 ? 1 : 0);
        for (int n = 0; n < drops; n++) pickups.Add(new Pickup { Position = e.Position + RandomDir() * Rand(0, 35), Value = e.Kind == EnemyKind.Boss ? 2 : 1 });
    }

    static void UpdatePickups(float dt)
    {
        for (int i = pickups.Count - 1; i >= 0; i--)
        {
            Pickup p = pickups[i]; p.Age += dt;
            Vector2 d = player - p.Position; float dist = d.Length();
            if (dist < 125 && dist > 1) p.Position += Vector2.Normalize(d) * (280 - dist) * dt;
            if (dist < 25)
            { scrap += p.Value; score += p.Value * 15; floaters.Add(new Floater(p.Position, $"+{p.Value} scrap", Color.Gold)); pickups.RemoveAt(i); }
        }
    }

    static void BeginUpgrade()
    {
        state = GameState.Upgrade;
        List<Upgrade> pool = Enum.GetValues<Upgrade>().ToList();
        for (int i = 0; i < 3; i++) { int n = rng.Next(pool.Count); choices[i] = pool[n]; pool.RemoveAt(n); }
    }

    static void PickUpgrade(int index)
    {
        switch (choices[index])
        {
            case Upgrade.Damage: damage += 8; break;
            case Upgrade.FireRate: fireDelay = Math.Max(.075f, fireDelay * .82f); break;
            case Upgrade.Speed: speed += 35; break;
            case Upgrade.Armor: maxHealth += 25; health = Math.Min(maxHealth, health + 25); break;
            case Upgrade.Repair: health = Math.Min(maxHealth, health + 50); break;
            case Upgrade.Salvage: scrap += 8; score += 150; break;
        }
        wave++; waveTime = 0; spawnTimer = .8f; bannerTime = 2.5f; bossSpawned = false;
        bullets.Clear(); state = GameState.Playing;
    }

    static void UpdateEffects(float dt)
    {
        shake = Math.Max(0, shake - 35 * dt);
        for (int i = particles.Count - 1; i >= 0; i--) { Particle p = particles[i]; p.Position += p.Velocity * dt; p.Velocity *= .94f; p.Life -= dt; if (p.Life <= 0) particles.RemoveAt(i); }
        for (int i = floaters.Count - 1; i >= 0; i--) { Floater f = floaters[i]; f.Position.Y -= 34 * dt; f.Life -= dt; if (f.Life <= 0) floaters.RemoveAt(i); }
    }

    static void Draw()
    {
        Raylib.BeginDrawing();
        Raylib.ClearBackground(new Color(17, 20, 19, 255));
        if (state == GameState.Title) DrawTitle();
        else
        {
            Vector2 offset = shake > 0 ? RandomDir() * shake : Vector2.Zero;
            Raylib.BeginMode2D(new Camera2D { Offset = offset, Target = Vector2.Zero, Rotation = 0, Zoom = 1 });
            DrawArena(); DrawPickups(); DrawBullets(); DrawEnemies(); DrawPlayer(); DrawEffects();
            Raylib.EndMode2D();
            DrawHud();
            if (bannerTime > 0 && state == GameState.Playing) DrawCentered(wave == 6 ? "FINAL WAVE: THE COMPACTOR" : $"WAVE {wave}", 126, 30, Color.Orange);
            if (state == GameState.Paused) DrawOverlay("PAUSED", "Press P or Esc to resume");
            if (state == GameState.GameOver) DrawEnd(false);
            if (state == GameState.Victory) DrawEnd(true);
            if (state == GameState.Upgrade) DrawUpgrade();
        }
        Raylib.EndDrawing();
    }

    static void DrawTitle()
    {
        DrawArena();
        for (int i = 0; i < 9; i++) { int x = 90 + i * 110; Raylib.DrawCircle(x, 155 + (i % 3) * 35, 24, new Color(75, 35, 28, 255)); }
        DrawCentered("SCRAPZONE", 170, 72, Color.Orange);
        DrawCentered("LAST SALVAGER", 245, 29, Color.SkyBlue);
        DrawCentered("Survive six waves. Recycle the horde. Defeat the Compactor.", 320, 20, Color.LightGray);
        Raylib.DrawRectangle(W / 2 - 245, 370, 490, 150, new Color(8, 11, 10, 225));
        DrawCentered("WASD / ARROWS   MOVE", 390, 18, Color.White);
        DrawCentered("MOUSE + LEFT CLICK   AIM / FIRE", 423, 18, Color.White);
        DrawCentered("SPACE   DASH       P / ESC   PAUSE", 456, 18, Color.White);
        DrawCentered("Collect glowing scrap and pick an upgrade after each wave.", 492, 16, Color.Gray);
        if ((int)(Raylib.GetTime() * 2) % 2 == 0) DrawCentered("PRESS ENTER OR CLICK TO DEPLOY", 575, 24, Color.Yellow);
    }

    static void DrawArena()
    {
        for (int x = 0; x < W; x += 50) Raylib.DrawLine(x, (int)ArenaTop, x, H, new Color(31, 36, 33, 255));
        for (int y = (int)ArenaTop; y < H; y += 50) Raylib.DrawLine(0, y, W, y, new Color(31, 36, 33, 255));
        Raylib.DrawRectangle(105, 175, 135, 58, new Color(34, 38, 31, 255));
        Raylib.DrawRectangle(710, 430, 205, 92, new Color(38, 34, 30, 255));
        Raylib.DrawRectangle(390, 315, 150, 44, new Color(31, 37, 31, 255));
        Raylib.DrawLine(0, (int)ArenaTop, W, (int)ArenaTop, Color.DarkGray);
    }

    static void DrawPlayer()
    {
        Color c = invincible > 0 && (int)(invincible * 18) % 2 == 0 ? Color.White : Color.SkyBlue;
        Raylib.DrawCircleV(player, 21, new Color(20, 70, 95, 255)); Raylib.DrawCircleV(player, 16, c);
        Raylib.DrawLineEx(player, player + aim * 29, 7, Color.LightGray); Raylib.DrawCircleV(player, 5, Color.White);
    }

    static void DrawEnemies()
    {
        foreach (Enemy e in enemies)
        {
            Raylib.DrawCircleV(e.Position, e.Radius + 3, new Color(55, 22, 20, 255)); Raylib.DrawCircleV(e.Position, e.Radius, e.Color);
            if (e.Kind is EnemyKind.Tank or EnemyKind.Boss) Raylib.DrawCircleLines((int)e.Position.X, (int)e.Position.Y, e.Radius * .62f, Color.DarkBrown);
            if (e.Kind == EnemyKind.Shooter) Raylib.DrawCircleV(e.Position, 7, Color.Pink);
            if (e.Kind == EnemyKind.Runner) Raylib.DrawCircleV(e.Position, 5, Color.Yellow);
            if (e.Kind == EnemyKind.Boss)
            {
                float ratio = e.Health / e.MaxHealth;
                Raylib.DrawRectangle(250, 94, 500, 13, Color.DarkGray); Raylib.DrawRectangle(250, 94, (int)(500 * ratio), 13, Color.Red);
            }
        }
    }

    static void DrawBullets()
    { foreach (Bullet b in bullets) Raylib.DrawCircleV(b.Position, b.Radius, b.EnemyShot ? Color.Pink : Color.Yellow); }

    static void DrawPickups()
    {
        foreach (Pickup p in pickups)
        {
            float pulse = 2 + MathF.Sin(p.Age * 7) * 2;
            Raylib.DrawCircleV(p.Position, 11 + pulse, new Color(85, 55, 12, 130));
            Raylib.DrawRectangle((int)p.Position.X - 6, (int)p.Position.Y - 6, 12, 12, Color.Gold);
        }
    }

    static void DrawEffects()
    {
        foreach (Particle p in particles) Raylib.DrawCircleV(p.Position, p.Size, p.Color);
        foreach (Floater f in floaters) Raylib.DrawText(f.Text, (int)f.Position.X, (int)f.Position.Y, 16, f.Color);
    }

    static void DrawHud()
    {
        Raylib.DrawRectangle(0, 0, W, (int)ArenaTop, new Color(9, 12, 11, 255));
        Raylib.DrawText("SCRAPZONE", 18, 12, 25, Color.Orange);
        Raylib.DrawText($"WAVE {wave}/6", 188, 16, 20, Color.White);
        Raylib.DrawText($"SCRAP {scrap}", 320, 16, 20, Color.Gold);
        Raylib.DrawText($"SCORE {score:000000}", 455, 16, 20, Color.White);
        Raylib.DrawText($"KILLS {kills}", 690, 16, 20, Color.LightGray);
        Raylib.DrawRectangle(18, 52, 270, 18, Color.DarkGray);
        Raylib.DrawRectangle(18, 52, (int)(270 * Math.Clamp((float)health / maxHealth, 0, 1)), 18, health < maxHealth / 3 ? Color.Red : Color.Green);
        Raylib.DrawText($"HULL {health}/{maxHealth}", 92, 53, 15, Color.White);
        float dashReady = Math.Clamp(1 - dashCooldown / 1.35f, 0, 1);
        Raylib.DrawText("DASH", 320, 54, 15, Color.LightGray); Raylib.DrawRectangle(370, 56, 90, 10, Color.DarkGray); Raylib.DrawRectangle(370, 56, (int)(90 * dashReady), 10, Color.SkyBlue);
        float remaining = Math.Max(0, WaveDuration() - waveTime);
        Raylib.DrawText(wave == 6 ? "BOSS" : $"NEXT {remaining:00.0}s", 810, 53, 16, Color.LightGray);
    }

    static void DrawUpgrade()
    {
        Raylib.DrawRectangle(0, 0, W, H, new Color(0, 0, 0, 205));
        DrawCentered("WAVE CLEARED", 130, 38, Color.Orange); DrawCentered("Choose one upgrade", 185, 20, Color.White);
        for (int i = 0; i < 3; i++)
        {
            int x = 65 + i * 310;
            Raylib.DrawRectangle(x, 250, 250, 235, new Color(24, 31, 29, 255));
            Raylib.DrawRectangleLines(x, 250, 250, 235, Color.SkyBlue);
            DrawTextCenteredIn($"[{i + 1}]", x, 275, 250, 28, Color.Yellow);
            DrawTextCenteredIn(UpgradeName(choices[i]), x, 335, 250, 24, Color.White);
            DrawTextCenteredIn(UpgradeDescription(choices[i]), x + 12, 395, 226, 17, Color.LightGray);
        }
    }

    static void DrawEnd(bool won)
    {
        Raylib.DrawRectangle(0, 0, W, H, new Color(0, 0, 0, 215));
        DrawCentered(won ? "ZONE SECURED" : "SALVAGER LOST", 190, 48, won ? Color.Green : Color.Orange);
        DrawCentered(won ? "The Compactor is scrap." : $"Overrun during wave {wave}.", 255, 21, Color.White);
        Raylib.DrawRectangle(W / 2 - 190, 315, 380, 145, new Color(20, 25, 23, 255));
        DrawCentered($"SCORE   {score:000000}", 335, 24, Color.Yellow);
        DrawCentered($"KILLS   {kills}     SCRAP   {scrap}", 380, 20, Color.White);
        int accuracy = shots == 0 ? 0 : hits * 100 / shots;
        DrawCentered($"ACCURACY   {accuracy}%", 420, 18, Color.LightGray);
        DrawCentered("PRESS R OR ENTER TO RUN AGAIN", 530, 22, Color.SkyBlue);
    }

    static void DrawOverlay(string title, string subtitle)
    { Raylib.DrawRectangle(0, 0, W, H, new Color(0, 0, 0, 180)); DrawCentered(title, 290, 46, Color.White); DrawCentered(subtitle, 355, 20, Color.LightGray); }

    static void DrawCentered(string text, int y, int size, Color color)
    { Raylib.DrawText(text, W / 2 - Raylib.MeasureText(text, size) / 2, y, size, color); }
    static void DrawTextCenteredIn(string text, int x, int y, int width, int size, Color color)
    { Raylib.DrawText(text, x + width / 2 - Raylib.MeasureText(text, size) / 2, y, size, color); }

    static string UpgradeName(Upgrade u) => u switch { Upgrade.Damage => "CUTTING ROUNDS", Upgrade.FireRate => "OVERCLOCK", Upgrade.Speed => "HOT WHEELS", Upgrade.Armor => "PLATE WELD", Upgrade.Repair => "FIELD REPAIR", _ => "SALVAGE CACHE" };
    static string UpgradeDescription(Upgrade u) => u switch { Upgrade.Damage => "+8 weapon damage", Upgrade.FireRate => "+18% fire rate", Upgrade.Speed => "+35 move speed", Upgrade.Armor => "+25 max hull\nand repair 25", Upgrade.Repair => "Repair 50 hull", _ => "+8 scrap and\n+150 score" };

    static void Burst(Vector2 pos, Color color, int count)
    { for (int i = 0; i < count; i++) AddParticle(pos, color, RandomDir() * Rand(30, 210), Rand(.25f, .7f), Rand(2, 6)); }
    static void AddParticle(Vector2 p, Color c, Vector2 v, float life, float size) => particles.Add(new Particle { Position = p, Color = c, Velocity = v, Life = life, Size = size });
    static Vector2 RandomDir() { float a = Rand(0, MathF.PI * 2); return Dir(a); }
    static Vector2 Dir(float a) => new(MathF.Cos(a), MathF.Sin(a));
    static float Rand(float a, float b) => a + (float)rng.NextDouble() * (b - a);

    enum GameState { Title, Playing, Paused, Upgrade, GameOver, Victory }
    enum EnemyKind { Chaser, Runner, Tank, Shooter, Boss }
    enum Upgrade { Damage, FireRate, Speed, Armor, Repair, Salvage }

    sealed class Enemy
    {
        public EnemyKind Kind; public Vector2 Position; public float Health, MaxHealth, Speed, Radius, ShootTimer; public int ContactDamage; public Color Color;
        public Enemy(EnemyKind kind, Vector2 pos, float hp, float speed, int damage, float radius, Color color)
        { Kind = kind; Position = pos; Health = MaxHealth = hp; Speed = speed; ContactDamage = damage; Radius = radius; Color = color; ShootTimer = 1; }
    }
    sealed class Bullet { public Vector2 Position, Velocity; public float Life, Radius = 5; public int Damage; public bool EnemyShot; }
    sealed class Pickup { public Vector2 Position; public int Value; public float Age; }
    sealed class Particle { public Vector2 Position, Velocity; public float Life, Size; public Color Color; }
    sealed class Floater { public Vector2 Position; public string Text; public Color Color; public float Life = .9f; public Floater(Vector2 p, string t, Color c) { Position = p; Text = t; Color = c; } }
}
